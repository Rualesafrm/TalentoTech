namespace ChinookDatabase.Test.DatabaseTests
{
    public class DatabaseFixture
    {
	}
}
