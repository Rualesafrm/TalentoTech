namespace ChinookDatabase.DdlStrategies
{
    public enum PrimaryKeyStrategy
    {
        None,
        Identity,
        Serial
    }
}